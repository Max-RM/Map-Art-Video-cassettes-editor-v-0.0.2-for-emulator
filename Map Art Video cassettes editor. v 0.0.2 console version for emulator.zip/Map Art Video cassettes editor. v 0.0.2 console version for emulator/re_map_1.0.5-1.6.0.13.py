import os
file = "step_2.txt"
with open(file, 'r', encoding="utf-8") as infe:
    s = infe.read()
res = str(s).replace('Name:"minecraft:map"','id:358s')
with open('step_3.txt', 'w', encoding="utf-8") as f:
    f.write(res)

