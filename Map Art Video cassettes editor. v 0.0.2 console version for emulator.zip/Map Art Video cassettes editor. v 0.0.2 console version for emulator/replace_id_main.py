import re

print("")
print("")
print("")
print("enter the starting map uuid and click enter button")

n = int(input())
with open('step_1.txt', 'r', encoding="utf-8") as infe:
    s = infe.read()


res = re.sub(r'(?<=map_uuid:)\d+(?=L}})', lambda x: f'{int(x.group()) + n}', s)

with open('step_2.txt', 'w', encoding="utf-8") as f:
    f.write(res)
