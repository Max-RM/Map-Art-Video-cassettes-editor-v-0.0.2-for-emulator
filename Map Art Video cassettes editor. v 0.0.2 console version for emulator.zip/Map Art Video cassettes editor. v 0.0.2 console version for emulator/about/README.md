this software was developed on 15.09.2021 by TNT ENTERTAINMENT Inc.
The performance of the program is not guaranteed, so be sure to make a backup copy of your files
before you start working with "Map Art Video cassettes editor v 0.0.2". This program may be freely distributed by you,
provided that the copyright of TNT ENTERTAINMENT inc. is preserved. The basis of the program is the technology
"Map art video" was developed on April 10, 2021 by the founder of TNT ENTERTAINMENT Inc - Max RM.
Link to my channel https://www.youtube.com/channel/UCya5kPSOPA_7LnFkRTWk8Eg
