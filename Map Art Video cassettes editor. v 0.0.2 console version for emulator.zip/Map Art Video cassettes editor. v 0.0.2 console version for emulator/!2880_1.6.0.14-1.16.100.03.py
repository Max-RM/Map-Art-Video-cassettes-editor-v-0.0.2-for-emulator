import os
os.system("color 2")
os.system("2880.cmd")
os.system("replace_id_main.py")
os.system("re_map_1.6.0.14-1.16.100.03.py")
os.system("to_schematic.cmd")
os.remove("step_1.txt")
os.remove("step_2.txt")
os.remove("step_3.txt")
